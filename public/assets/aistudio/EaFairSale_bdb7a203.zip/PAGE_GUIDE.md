# 📖 คู่มือแนะนำหน้าเว็บและระบบการทำงาน — EA Fair Sale

คู่มือแนะนำโครงสร้างหน้าจอ ส่วนประกอบของโค้ด ไฟล์สไตล์ (CSS) ไฟล์ควบคุม (JS) และวิธีการใช้งานทุกหน้าของระบบ **EA Fair Sale** อย่างละเอียด

---

## 📑 สารบัญหน้าจอ (Page Directory)

1. [หน้าหลัก & เมนูรวม (Home / Menu)](#1-หน้าหลัก--เมนูรวม-home--menu)
2. [ระบบขายสินค้าหน้าร้าน (Sale / POS)](#2-ระบบขายสินค้าหน้าร้าน-sale--pos)
3. [แดชบอร์ดสรุปยอดวันนี้ (Dashboard Today)](#3-แดชบอร์ดสรุปยอดวันนี้-dashboard-today)
4. [แดชบอร์ดภาพรวมทั้งหมด (Dashboard All-Time)](#4-แดชบอร์ดภาพรวมทั้งหมด-dashboard-all-time)
5. [คลังสินค้า & สต็อกขั้นต่ำ (Stock & Low Stock)](#5-คลังสินค้า--สต็อกขั้นต่ำ-stock--low-stock)
6. [ประวัติการเคลื่อนไหวสต็อก (Stock Movements)](#6-ประวัติการเคลื่อนไหวสต็อก-stock-movements)
7. [ระบบตรวจนับสต็อกจริง (Physical Inventory Audit)](#7-ระบบตรวจนับสต็อกจริง-physical-inventory-audit)
8. [ประวัติการขาย & บิลย้อนหลัง (Sales History)](#8-ประวัติการขาย--บิลย้อนหลัง-sales-history)
9. [บันทึกรายจ่าย & ต้นทุน (Expenses)](#9-บันทึกรายจ่าย--ต้นทุน-expenses)
10. [รายงานสรุป & พิมพ์เอกสาร A4/สลิป (Reports & Printing)](#10-รายงานสรุป--พิมพ์เอกสาร-a4สลิป-reports--printing)
11. [ตั้งค่าระบบ & เชื่อมต่อฐานข้อมูล (Settings)](#11-ตั้งค่าระบบ--เชื่อมต่อฐานข้อมูล-settings)
12. [โครงสร้างสถาปัตยกรรมไฟล์ (File Architecture Map)](#12-โครงสร้างสถาปัตยกรรมไฟล์-file-architecture-map)

---

## 1. หน้าหลัก & เมนูรวม (Home / Menu)
* **รหัสหน้า (Route ID):** `'home'` หรือ `'menu'`
* **ฟังก์ชันควบคุม:** `renderHome()` / `renderMenu()`
* **ไฟล์สไตล์ที่เกี่ยวข้อง:** `css/pages/home.css`, `css/layout.css`

### 🎯 หน้าที่และฟังก์ชันการทำงาน:
- เป็นศูนย์กลางควบคุม (Dashboard Hub) รวบรวมทางลัดไปยังทุกฟังก์ชันในระบบ
- **แถบเป้าหมายยอดขายประจำวัน (Daily Revenue Goal Widget):** แสดงยอดขายวันนี้เทียบกับเป้าหมายที่ตั้งไว้ (เช่น ฿3,200 / ฿5,000) พร้อมแถบ Progress Bar สีเขียว-ฟ้า คำนวณเป็นเปอร์เซ็นต์อัตโนมัติ
- **การ์ดทางลัด (Action Tiles):** ปุ่มกดเข้าสู่ 8 โมดูลหลัก ได้แก่:
  1. ขายสินค้า (POS)
  2. แดชบอร์ดวันนี้
  3. คลังสินค้า
  4. ตรวจนับสต็อก (Audit)
  5. ประวัติการขาย
  6. รายจ่าย
  7. รายงานสรุป
  8. ตั้งค่า

---

## 2. ระบบขายสินค้าหน้าร้าน (Sale / POS)
* **รหัสหน้า (Route ID):** `'sale'`
* **ฟังก์ชันควบคุม:** `renderSale()`
* **ไฟล์สไตล์ที่เกี่ยวข้อง:** `css/pages/pos.css`, `css/components/buttons.css`

### 🎯 หน้าที่และฟังก์ชันการทำงาน:
- **โหมดการขาย 2 รูปแบบ:**
  - **Grid Mode:** แตะการ์ดสินค้าเพื่อเพิ่มเข้าตะกร้า พร้อมแสดงป้ายจำนวนสต็อกคงเหลือ
  - **Scan Mode:** โหมดสแกนบาร์โค้ดต่อเนื่องด้วยปืนยิงบาร์โค้ด หรือเปิดกล้องมือถือสแกนสด
- **ตะกร้าสินค้า (Cart Management):**
  - ปรับจำนวนชิ้น `[+]` `[-]` หรือลบรายการ
  - กำหนดส่วนลดรายชิ้น (Line Discount)
  - กำหนดส่วนลดท้ายบิล (Bill Discount) ทั้งแบบเปอร์เซ็นต์ `%` หรือจำนวนเงินสด `บาท`
- **ระบบคิดเงิน & เงินทอน (Smart Checkout):**
  - **ปุ่มเงินสดด่วน (Quick Cash):** คลิกเดียวระบุเงินรับ `+20`, `+50`, `+100`, `+500`, `+1,000` หรือปุ่ม `พอดี (Exact)`
  - **คำนวณเงินทอนละเอียด (Change Breakdown):** คำนวณแยกชนิดธนบัตรและเหรียญที่ต้องทอนลูกค้า (เช่น แบงก์ 100 x 1, เหรียญ 10 x 2)
  - รองรับการชำระด้วย **เงินสด (Cash)** และ **พร้อมเพย์ (PromptPay QR Code)**
- **การตัดสต็อก & บันทึก:** ตัดสต็อกแบบ Real-time พร้อมออกใบเสร็จความร้อนทันที
- **ระบบทำงานออฟไลน์ & ซิงค์อัตโนมัติ (Background Service Worker & Auto-Sync):**
  - หากอินเทอร์เน็ตขาดหาย แคชเชียร์ยังสามารถคิดเงินและเปิดบิลขายออฟไลน์ได้อย่างต่อเนื่องไม่มีสะดุด ข้อมูลจะถูกเก็บอย่างปลอดภัยใน IndexedDB (`pending_pos_sales`)
  - ทันทีที่เน็ตกลับมาต่อติด ระบบ Service Worker (`sw.js`) และ `js/offline-sync.js` จะตรวจจับสถานะเชื่อมต่อและทำการซิงค์บิลออฟไลน์ขึ้น Supabase โดยอัตโนมัติในเบื้องหลัง
  - มีแถบสถานะเครือข่ายและปุ่มกดซิงค์ทันที (Manual Sync) บนหน้าจอ POS และส่วนหัวของแอปพลิเคชัน (App Bar) พร้อมแอนิเมชันแจ้งเตือนเมื่อซิงค์สำเร็จ

---

## 3. แดชบอร์ดสรุปยอดวันนี้ (Dashboard Today)
* **รหัสหน้า (Route ID):** `'dashboardToday'`
* **ฟังก์ชันควบคุม:** `renderDashboardToday()`
* **ไฟล์สไตล์ที่เกี่ยวข้อง:** `css/pages/dashboard.css`

### 🎯 หน้าที่และฟังก์ชันการทำงาน:
- **ตัวเลือกช่วงเวลา (Date Range Picker & Quick Presets):**
  - ปุ่มลัดเลือกช่วงเวลาด่วน: วันนี้ (Today), เมื่อวาน (Yesterday), 7 วันล่าสุด (7 Days), 30 วัน (30 Days), ตลอดงาน (All)
  - ช่องกรอกวันที่แบบกำหนดเอง (Custom Date Range): เลือกวันที่เริ่มต้น - สิ้นสุด และกดค้นหาช่วงวันที่ได้ทันที
- **การ์ดสรุปตัวเลขสำคัญ (KPIs):**
  - ยอดขายรวมสุทธิ (Net Revenue)
  - ยอดขายก่อนลด & ยอดส่วนลด (Gross Total & Discounts)
  - จำนวนบิลที่เปิด (Bill Count) & ยอดขายเฉลี่ยต่อบิล (Avg. Ticket Size)
  - จำนวนชิ้นสินค้ารวมที่จำหน่าย (Total Units Sold)
  - ยอดเงินสดสะสม (Cash) เทียบกับ ยอดสแกน QR PromptPay (PromptPay QR)
- **กราฟวิเคราะห์แนวโน้ม D3.js (Interactive Trend Chart):**
  - เมื่อเลือกช่วงวันแบบหลายวัน ระบบจะเรนเดอร์กราฟเปรียบเทียบยอดขายรายวัน D3.js พร้อมสลับมิติได้ (ยอดขาย / จำนวนบิล / เงินสด vs QR) พร้อมป้ายบอก "วันพีคยอดขายสูงสุด (Peak Day)"
- **ตารางวิเคราะห์การกระจายตัวของยอดขาย:** แยกตามช่วงเวลาของวัน (เช้า/บ่าย/เย็น/ค่ำ) หรือตามรายวัน พร้อมอันดับสินค้าขายดีและข้อมูลขนาดตะกร้า (Basket Analysis)

---

## 4. แดชบอร์ดภาพรวมทั้งหมด & เปรียบเทียบยอดขายรายวัน (Dashboard All-Time)
* **รหัสหน้า (Route ID):** `'dashboardAll'`
* **ฟังก์ชันควบคุม:** `renderDashboardAll()`
* **ไฟล์สไตล์ที่เกี่ยวข้อง:** `css/pages/dashboard.css`

### 🎯 หน้าที่และฟังก์ชันการทำงาน:
- **ตัวกรองช่วงเวลาอัจฉริยะสำหรับผู้จัดการ (Executive Date Range Picker):**
  - มีปุ่มลัดเลือกช่วงเวลา: 🌐 ทั้งหมด, 📅 วันนี้, ⏪ เมื่อวาน, 📆 7 วันล่าสุด, 🗓️ 30 วัน, 📊 เดือนนี้
  - กล่องเลือกช่วงวันที่แบบกำหนดเอง (Custom Date Inputs: ตั้งแต่วันที่ - ถึงวันที่) พร้อมปุ่ม `🔍 กรองข้อมูล` และปุ่ม `✕ ล้างตัวกรอง`
  - ป้ายระบุช่วงวันที่ที่กำลังแสดงผล (Date Range Badge) ชัดเจน
- **การคำนวณ KPI แบบไดนามิกตามช่วงเวลาที่เลือก:**
  - อัปเดต 6 การ์ดตัวชี้วัดหลักทันที: ยอดขายสุทธิ, ยอดขายก่อนหักส่วนลด, จำนวนชิ้นที่จำหน่าย, จำนวนวันทำการเฉลี่ยต่อวัน, ยอดเงินสด และยอด QR PromptPay
- **กราฟเปรียบเทียบยอดขายรายวัน D3.js (All-Days Daily Sales Comparison Chart):**
  - อัปเดตกราฟแท่งและเส้นค่าเฉลี่ยตามช่วงเวลาที่กรองแบบ Real-time
  - สลับดู 3 มิติข้อมูล: 💰 ยอดขาย (Revenue), 🧾 จำนวนบิล (Bills), 💳 แยกเงินสด vs QR (Cash vs QR)
  - ชิปสรุปสถิติ: ยอดขายเฉลี่ยต่อวัน, วันพีคยอดขายสูงสุด (Peak Revenue Day), วันพีคจำนวนบิลสูงสุด (Max Bills Day)
- **ตารางสรุปผลประกอบการ:**
  - ยอดขายแยกตามรายวัน (Daily Breakdown) พร้อมเปอร์เซ็นต์สัดส่วน
  - ผลงานแยกตามจุดแคชเชียร์ (Terminal Performance)
  - สัดส่วนยอดขายแยกตามหมวดหมู่สินค้า (Category Share)
  - 10 อันดับสินค้าขายดี และการวิเคราะห์พฤติกรรมการซื้อตะกร้าสินค้า (Basket Analytics)

---

## 5. คลังสินค้า & สต็อกขั้นต่ำ (Stock & Low Stock)
* **รหัสหน้า (Route ID):** `'stock'` และ `'lowStock'`
* **ฟังก์ชันควบคุม:** `renderStock()`, `renderLowStock()`, `openStockDetailModal()`
* **ไฟล์สไตล์ที่เกี่ยวข้อง:** `css/pages/stock.css`, `css/components/tables.css`

### 🎯 หน้าที่และฟังก์ชันการทำงาน:
- **มุมมองแสดงผล 2 โหมด:** สลับได้ระหว่างแบบ **การ์ด (Grid Cards)** หรือแบบ **ตารางข้อมูล (Data Table)**
- **ตัวกรองสถานะสินค้า (Filter Chips):** ทั้งหมด (All), สต็อกปกติ (In Stock), ใกล้หมด (Low Stock), หมดสต็อก (Out of Stock)
- **การจัดการสินค้า:** เพิ่มสินค้าใหม่, แก้ไขราคาขาย, ราคาทุน, บาร์โค้ด, หน่วยนับ (ชิ้น, กล่อง, ขวด, แพ็ก)
- **ระบบคำนวณและแนะนำสั่งเติมสต็อกอัตโนมัติ (Auto-Suggest Refill Engine):**
  - คำนวณอัตราความเร็วการขายต่อวัน (Sales Velocity)
  - คาดการณ์จำนวนวันที่สต็อกจะหมด (Days to Stockout)
  - แนะนำปริมาณสั่งซื้อที่เหมาะสมตามระยะเวลาสั่งของ (Lead Time) และระดับความปลอดภัย (Safety Buffer)
- **ระบบเตือนระฆัง (Bell Notification):** แจ้งเตือนสินค้าใกล้หมดที่ส่วนหัวเว็บ พร้อมระบบส่งอีเมลแจ้งเตือนผู้ดูแล

---

## 6. ประวัติการเคลื่อนไหวสต็อก (Stock Movements)
* **รหัสหน้า (Route ID):** `'movement'`
* **ฟังก์ชันควบคุม:** `renderMovement()`, `openQuickStockInModal()`
* **ไฟล์สไตล์ที่เกี่ยวข้อง:** `css/pages/movement.css`

### 🎯 หน้าที่และฟังก์ชันการทำงาน:
- บันทึก Log ทุกการเปลี่ยนแปลงของสินค้าอย่างโปร่งใส:
  - `IN (รับเข้า)`: รับสินค้าจากการสั่งซื้อเพิ่ม
  - `OUT (จ่ายออก)`: ตัดสต็อกอัตโนมัติเมื่อเกิดการขายหน้าร้าน POS
  - `ADJUST (ปรับปรุง)`: ปรับยอดสต็อกจากการตรวจนับสินค้าจริง
- **ปุ่มรับเข้าด่วน (Quick Receive):** สแกนหรือเลือกสินค้าแล้วระบุจำนวนรับเข้าเพื่อเพิ่มยอดสต็อกได้ทันที

---

## 7. ระบบตรวจนับสต็อกจริง (Physical Inventory Audit)
* **รหัสหน้า (Route ID):** `'audit'`
* **ฟังก์ชันควบคุม:** `renderPhysicalAuditPage()`, `handleAuditScannedBarcode()`, `toggleAuditBulkMode()`
* **ไฟล์สไตล์ที่เกี่ยวข้อง:** `css/pages/audit.css`

### 🎯 หน้าที่และฟังก์ชันการทำงาน:
- **สถานีสแกนตรวจนับ (Live Audit Station):**
  - รองรับเครื่องสแกน USB / Bluetooth หรือเปิดกล้องมือถือสแกนสด
  - **ปุ่มสลับโหมดชิ้นเดี่ยว vs เพิ่มแบบกลุ่ม (Single vs. Bulk Add Mode):**
    - `⚡ ชิ้นเดี่ยว (1x)`: นับทีละ 1 ชิ้น
    - `📦 เพิ่มแบบกลุ่ม (Bulk Add)`: นับเป็นแพ็ก/โหล/ลัง (เช่น +5, +10, +12, +24, +50, +100 หรือพิมพ์ระบุจำนวนเองได้)
  - **แถบ HUD สแกนล่าสุด:** แสดงชื่อสินค้าที่เพิ่งยิงบาร์โค้ด พร้อมปุ่มกดยกเลิก (Undo) ทันทีหากยิงพลาด
- **ตารางเปรียบเทียบผลต่างสต็อก (Discrepancy Matrix):**
  - แสดง: ยอดในระบบ | ยอดนับจริง | ผลต่าง (ขาดหายติดลบสีแดง / เกินมาบวกสีเขียว)
- **เครื่องมือส่งออกและปรับยอด:**
  - พิมพ์รายงานผลต่างสต็อก
  - ส่งออกข้อมูลเป็น **Excel (.xls)** หรือ **CSV**
  - **ปุ่มยืนยันปรับสต็อก (Apply Adjustments):** อัปเดตยอดคงเหลือในระบบให้ตรงกับยอดนับจริงในคลิกเดียว

---

## 8. ประวัติการขาย & บิลย้อนหลัง (Sales History)
* **รหัสหน้า (Route ID):** `'salesHistory'`
* **ฟังก์ชันควบคุม:** `renderSalesHistory()`, `openSaleDetailModal()`
* **ไฟล์สไตล์ที่เกี่ยวข้อง:** `css/pages/sales-history.css`

### 🎯 หน้าที่และฟังก์ชันการทำงาน:
- ค้นหาและตรวจสอบบิลขายย้อนหลังตามวันที่, ช่วงเวลา, ช่องทางชำระเงิน, จุดขาย
- คลิกที่บิลเพื่อเปิดหน้าต่าง **รายละเอียดบิล (Bill Detail Modal)** แสดง:
  - เลขที่บิล (Receipt No.)
  - รายการสินค้าที่ซื้อ จำนวน และราคา
  - ส่วนลด, ยอดรวมสุทธิ
  - จำนวนเงินรับ และเงินทอน
- **ปุ่มพิมพ์ใบเสร็จซ้ำ (Reprint Receipt):** พิมพ์สลิปความร้อนหรือบันทึกเป็นรูปภาพซ้ำได้ตลอดเวลา

---

## 9. บันทึกรายจ่าย & ต้นทุน (Expenses)
* **รหัสหน้า (Route ID):** `'expenses'`
* **ฟังก์ชันควบคุม:** `renderExpenses()`, `openExpenseModal()`
* **ไฟล์สไตล์ที่เกี่ยวข้อง:** `css/pages/expenses.css`

### 🎯 หน้าที่และฟังก์ชันการทำงาน:
- บันทึกค่าใช้จ่ายเบ็ดเตล็ดของร้าน เช่น ค่าเช่าพื้นที่, ค่าเดินทาง, ค่าอุปกรณ์, ค่าอาหารพนักงาน
- แยกหมวดหมู่ค่าใช้จ่ายชัดเจน พร้อมระบุผู้จ่ายและหมายเหตุ
- **การวิเคราะห์กำไรสุทธิ (Net Profit Calculation):**
  $$\text{กำไรสุทธิ} = \text{ยอดขายรวม} - \text{ต้นทุนสินค้า (COGS)} - \text{รายจ่ายอื่นๆ}$$

---

## 10. รายงานสรุป & พิมพ์เอกสาร A4/สลิป (Reports & Printing)
* **รหัสหน้า (Route ID):** `'report'`
* **ฟังก์ชันควบคุม:** `renderReport()`, `openA4DailyReportModal()`, `printReceiptModal()`
* **ไฟล์สไตล์ที่เกี่ยวข้อง:** `css/pages/reports.css`, `css/pages/modals.css`

### 🎯 หน้าที่และฟังก์ชันการทำงาน:
- **รายงานสรุปยอดขาย A4 (Daily Official Report):**
  - สร้างเอกสารขนาด A4 มาตรฐาน พร้อมหัวเอกสารชื่อร้าน วันที่ และเลขที่จุดขาย
  - สรุปตัวเลขยอดขายรวม, กำไรขั้นต้น, จำนวนบิล, สรุปการรับเงินสดและพร้อมเพย์
  - ตารางสรุป 10 อันดับสินค้าขายดี พร้อมสั่งพิมพ์ออกเครื่องพิมพ์หรือบันทึกเป็น PDF ได้ทันที
- **สลิปความร้อน (Thermal Receipt 58mm / 80mm):**
  - รองรับเครื่องพิมพ์สลิปใบเสร็จ Bluetooth และ USB
- **ส่งออกไฟล์ข้อมูลดิบ (Data Export):** ส่งออกรายการบิลขายทั้งหมดเป็นไฟล์ Excel และ CSV

---

## 11. ตั้งค่าระบบ & เชื่อมต่อฐานข้อมูล (Settings)
* **รหัสหน้า (Route ID):** `'settings'`
* **ฟังก์ชันควบคุม:** `renderSettings()`, `saveSettings()`
* **ไฟล์สไตล์ที่เกี่ยวข้อง:** `css/pages/settings.css`

### 🎯 หน้าที่และฟังก์ชันการทำงาน:
- **ข้อมูลร้านค้า:** แก้ไขชื่อร้าน, ข้อความส่วนหัว/ส่วนท้ายใบเสร็จ, เป้าหมายยอดขายประจำวัน
- **จุดขาย (Terminal Identifier):** กำหนดรหัสเครื่อง เช่น POS-01, POS-02 (ช่วยให้ร้านที่มีหลายเครื่องตัดสต็อกและแยกรหัสบิลไม่ซ้ำกัน)
- **Cloud Database (Supabase Sync):**
  - ระบุ `Supabase URL` และ `Anon Key` เพื่อเชื่อมต่อฐานข้อมูลบนคลาวด์
  - ไฟสถานะแสดงการเชื่อมต่อ: **ออนไลน์ (Connected)** หรือ **ออฟไลน์ (Offline Mode)**
  - เมื่อไม่มีเน็ต ระบบจะบันทึกข้อมูลลงเครื่องอัตโนมัติ และซิงค์ขึ้น Cloud เมื่อกลับมาออนไลน์
- **การสำรองข้อมูล (Backup & Restore):** ส่งออกและนำเข้าข้อมูลสินค้า ยอดขาย และสต็อก

---

## 12. โครงสร้างสถาปัตยกรรมไฟล์ (File Architecture Map)

```text
Ea_Fair_Sale/
│
├── 📄 index.html                      # Single-Page HTML Shell & Dialog Host
├── 📖 PAGE_GUIDE.md                   # คู่มือแนะนำระบบและโครงสร้างหน้าจอฉบับสมบูรณ์ (ไฟล์นี้)
│
├── 🎨 css/                            # สไตล์ชีตแยกตามระดับและหน้าจออย่างละเอียด
│   ├── variables.css                  # โทนสี Dark Theme, รัศมีขอบมน, เงา, และดีไซน์โทเคน
│   ├── base.css                       # Reset, Typography, Utilities, Scrollbars
│   ├── layout.css                     # Appbar, Header Badges, Content Layout, Bottom Nav, Toast
│   │
│   ├── components/                    # คอมโพเนนต์ UI พื้นฐานที่ใช้ร่วมกัน
│   │   ├── buttons.css                # ปุ่ม Primary, Success, Danger, Ghost, Pills
│   │   ├── cards.css                  # Surface Cards, Stat Badges, Card Headers
│   │   ├── forms.css                  # Input fields, Select dropdowns, Label typography
│   │   └── tables.css                 # Responsive Data Tables, Sticky Headers, Zebra stripes
│   │
│   └── pages/                         # สไตล์เฉพาะแต่ละหน้าจอ
│       ├── home.css                   # Hero banner, Quick action tiles
│       ├── pos.css                    # POS Checkout Terminal, Product Grid, Cart, Steppers
│       ├── dashboard.css              # KPI Metric Cards, Daily Revenue Goal Widget, D3 Charts
│       ├── stock.css                  # Stock Grid, Low Stock Badges, Auto-Suggest Refill Box
│       ├── movement.css               # Movement logs, Type badges (IN / OUT / ADJUST)
│       ├── audit.css                  # Physical Inventory Audit, Batch/Bulk Stepper, HUD banner
│       ├── sales-history.css          # Sales history transaction cards, Bill pills
│       ├── expenses.css               # Expense cards, Category tags, Financial summaries
│       ├── reports.css                # A4 Printable Daily Report Sheet & Thermal Slip styles
│       ├── settings.css               # Settings sections, Terminal switcher, Cloud DB status
│       └── modals.css                 # Backdrop blur, Dialog card shells, Modal headers
│
├── ⚙️ js/                             # โค้ด JavaScript จัดการข้อมูลและ Logic
│   ├── core/
│   │   └── state.js                   # Application State, Local Storage, Web Audio & Haptics
│   ├── services/
│   │   └── api.js                     # เชื่อมต่อ Supabase DB, แคชออฟไลน์, ระบบส่งอีเมลแจ้งเตือน
│   └── pages/
│       └── home.js                    # Home & Menu Controller Logic
│
├── 📦 index.css                       # Master Stylesheet Orchestrator (@import pipeline)
└── 🚀 index.js                        # Master Application Logic & Routing Controller
```
